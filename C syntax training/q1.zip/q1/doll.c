#include <stdio.h>

int main() {
    float dollarValue = 0, input = 0, converted = 0;
    printf("Enter dollar value!\n");
    scanf("%f",&dollarValue);
    printf("$           IS\n");
    while (scanf("%f", &input) == 1) {
        converted = input * dollarValue;
        printf("%.2f       %.2f\n",input,converted);
    }
}
