#include <stdio.h>
#include <math.h>

double myCos(double x);
double factorial(int i);

int main() {
    double input, output, realCos;

    printf("Enter the angle in radians: ");
    scanf("%lf", &input);

    realCos = cos(input);
    output = myCos(input);

    printf("The cosine of %.2lf radians according to my_cos is %f.\n The real value is %f\n", input, output, realCos);

    return 0;
}

double myCos(double x) {

    // Reduce the angle to the range [-2*pi, 2*pi]
    while (x > 2 * M_PI) {
        x -= 2 * M_PI;
    }

    while (x < -2 * M_PI) {
        x += 2 * M_PI;
    }

    double result = 1.0; // Initialize with the first term of the series
    double term = 1.0;
    int i = 1;

    while (fabs(term) > 1e-9) {
        term = pow(-1, i) * pow(x, 2 * i) / factorial(2 * i); // Calculate the next term in the series
        result += term; // Add the term to the result
        i++;
    }

    return result;
}

double factorial(int i) {
    double term = 1.0;
    for (int j = 1; j <= i; ++j) {
        term = term * j;
    }
    return term;
}
